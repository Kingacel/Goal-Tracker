package com.example.goaltracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Home-screen widget: up to three goals, each with a progress bar, percent done and days left,
 * plus a "+" button (new goal) and a "View all goals" button.
 */
public class GoalWidgetProvider extends AppWidgetProvider {

    static final String EXTRA_ADD_GOAL = "widget_add_goal";
    static final String EXTRA_GOAL_ID = "widget_goal_id";

    private static final int MAX_ROWS = 3;

    private static final int[] ROW = {R.id.w_row1, R.id.w_row2, R.id.w_row3};
    private static final int[] NAME = {R.id.w_name1, R.id.w_name2, R.id.w_name3};
    private static final int[] STARTED = {R.id.w_started1, R.id.w_started2, R.id.w_started3};
    private static final int[] PCT = {R.id.w_pct1, R.id.w_pct2, R.id.w_pct3};
    private static final int[] DAYS = {R.id.w_days1, R.id.w_days2, R.id.w_days3};
    // Dividers sit below row 1 and row 2.
    private static final int[] DIV = {R.id.w_div1, R.id.w_div2};

    private static final class Item {
        String id, name, created;
        int percent;
        Long days; // null = no deadline
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        List<Item> items = loadItems(context);

        PendingIntent openApp = activity(context, 0, null, false);
        PendingIntent addGoal = activity(context, 1, null, true);

        for (int id : ids) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.goal_widget);

            for (int i = 0; i < MAX_ROWS; i++) {
                if (i < items.size()) {
                    Item it = items.get(i);
                    v.setViewVisibility(ROW[i], View.VISIBLE);
                    v.setTextViewText(NAME[i], it.name);
                    v.setTextViewText(STARTED[i], startedText(it.created));
                    v.setTextViewText(PCT[i], it.percent + "% complete");
                    if (it.days == null) {
                        v.setTextViewText(DAYS[i], "–");
                    } else if (it.days < 0) {
                        v.setTextViewText(DAYS[i], "Passed");
                    } else {
                        v.setTextViewText(DAYS[i], it.days + (it.days == 1 ? " day" : " days"));
                    }
                    v.setOnClickPendingIntent(ROW[i], activity(context, 10 + i, it.id, false));
                } else if (i == 0) {
                    // No goals at all: show a friendly placeholder row.
                    v.setViewVisibility(ROW[0], View.VISIBLE);
                    v.setTextViewText(NAME[0], "No goals yet – tap +");
                    v.setTextViewText(STARTED[0], "");
                    v.setTextViewText(PCT[0], "");
                    v.setTextViewText(DAYS[0], "–");
                    v.setOnClickPendingIntent(ROW[0], addGoal);
                } else {
                    v.setViewVisibility(ROW[i], View.GONE);
                }
            }
            // A divider is only shown when the row below it is visible.
            for (int d = 0; d < DIV.length; d++) {
                v.setViewVisibility(DIV[d], items.size() > d + 1 ? View.VISIBLE : View.GONE);
            }

            v.setOnClickPendingIntent(R.id.w_root, openApp);
            v.setOnClickPendingIntent(R.id.w_viewall, openApp);
            v.setOnClickPendingIntent(R.id.w_add, addGoal);
            manager.updateAppWidget(id, v);
        }
    }

    /** Builds a PendingIntent that opens the app, optionally selecting a goal or adding a new one. */
    private static PendingIntent activity(Context c, int requestCode, String goalId, boolean add) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (goalId != null) i.putExtra(EXTRA_GOAL_ID, goalId);
        if (add) i.putExtra(EXTRA_ADD_GOAL, true);
        return PendingIntent.getActivity(c, requestCode, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Reads the goal snapshot saved by the Store and orders it by soonest deadline. */
    private static List<Item> loadItems(Context c) {
        List<Item> out = new ArrayList<>();
        SharedPreferences prefs = c.getSharedPreferences(Store.WIDGET_PREFS, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(prefs.getString("goals_json", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.optString("id", "");
                it.name = o.optString("name", "Untitled");
                it.created = o.optString("created", "");
                it.percent = Math.max(0, Math.min(100, o.optInt("pct", 0)));
                it.days = daysLeft(o.optString("deadline", ""));
                out.add(it);
            }
        } catch (Exception ignored) { }

        // Upcoming deadlines first (soonest on top), then passed ones, then goals without a deadline.
        Collections.sort(out, (x, y) -> Long.compare(rank(x.days), rank(y.days)));
        return out.size() > MAX_ROWS ? new ArrayList<>(out.subList(0, MAX_ROWS)) : out;
    }

    /** "Started: 1 Oct 2026" */
    private static String startedText(String created) {
        LocalDate d = Util.parse(created);
        if (d == null) return "";
        return "Started: " + d.getDayOfMonth() + " " + Util.MONTHS_SHORT[d.getMonthValue() - 1] + " " + d.getYear();
    }

    private static long rank(Long days) {
        if (days == null) return Long.MAX_VALUE;
        if (days < 0) return 1_000_000L - days; // passed goals after upcoming ones, most recent first
        return days;
    }

    /** Whole days from today to the deadline (null if no deadline). */
    private static Long daysLeft(String deadline) {
        LocalDate target = Util.parse(deadline);
        if (target == null) return null;
        return ChronoUnit.DAYS.between(LocalDate.now(), target);
    }

    /** Re-draws every placed widget (called whenever the app saves). */
    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, GoalWidgetProvider.class));
        if (ids != null && ids.length > 0) new GoalWidgetProvider().onUpdate(c, m, ids);
    }
}
