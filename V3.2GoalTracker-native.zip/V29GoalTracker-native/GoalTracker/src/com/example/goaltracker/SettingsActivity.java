package com.example.goaltracker;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

/** Settings screen. Currently: Appearance (System default / Light / Dark). */
public class SettingsActivity extends Activity {

    private Pal p;
    private int appliedMode;

    @Override
    protected void onCreate(Bundle b) {
        setTheme(Pal.themeRes(this));
        super.onCreate(b);
        appliedMode = Pal.mode(this);
        p = Pal.of(this);
        Pal.applyBars(this, p);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(p.bg);
        FrameLayout holder = new FrameLayout(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        int width = Math.min(getResources().getDisplayMetrics().widthPixels, dp(640));
        holder.addView(content, new FrameLayout.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_HORIZONTAL));
        scroll.addView(holder, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        // Header: back + title
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton back = new ImageButton(this);
        back.setImageResource(R.drawable.ic_back);
        back.setColorFilter(p.ink);
        back.setContentDescription("Back");
        back.setScaleType(ImageView.ScaleType.CENTER);
        TypedValue tvv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tvv, true);
        back.setBackgroundResource(tvv.resourceId);
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView title = text("Settings", 26, p.ink, true);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dp(6);
        head.addView(title, tl);
        content.addView(head);

        // Appearance section
        TextView sec = text("Appearance", 14, p.mute, true);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2, -2);
        sl.topMargin = dp(20);
        sl.bottomMargin = dp(8);
        sl.leftMargin = dp(6);
        content.addView(sec, sl);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.card);
        bg.setCornerRadius(dp(16));
        bg.setStroke(Math.max(1, dp(1)), p.line);
        card.setBackground(bg);
        content.addView(card, new LinearLayout.LayoutParams(-1, -2));

        addOption(card, Pal.MODE_LIGHT, "Light", "White background, dark text", false);
        addOption(card, Pal.MODE_DARK, "Dark", "Black background, light text", true);
        addOption(card, Pal.MODE_SYSTEM, "System default", "Follow the device's setting", true);
    }

    private void addOption(LinearLayout card, int mode, String label, String sub, boolean divider) {
        if (divider) {
            View d = new View(this);
            d.setBackgroundColor(p.line);
            card.addView(d, new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));
        }
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(64));
        row.setPadding(dp(16), dp(10), dp(12), dp(10));
        TypedValue tvv = new TypedValue();
        if (getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tvv, true)) {
            row.setBackgroundResource(tvv.resourceId);
        }

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.addView(text(label, 16, p.ink, true));
        labels.addView(text(sub, 13, p.mute, false));
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));

        RadioButton rb = new RadioButton(this);
        rb.setChecked(appliedMode == mode);
        rb.setClickable(false);
        rb.setFocusable(false);
        rb.setButtonTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}}, new int[]{p.acc, p.mute}));
        row.addView(rb, new LinearLayout.LayoutParams(-2, -2));

        row.setOnClickListener(v -> choose(mode));
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    /** Saves the choice, refreshes the widget so it matches, and re-draws this screen. */
    private void choose(int mode) {
        if (mode == appliedMode) return;
        Pal.setMode(this, mode);
        GoalWidgetProvider.refresh(this);
        recreate();
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(float v) { return Util.dp(this, v); }
}
