package com.example.goaltracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.AlarmManager;
import android.view.View;
import android.widget.RemoteViews;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Home-screen widget: up to three goals, each with a progress bar, percent done and days left,
 * plus a "+" button (new goal) and a "View all goals" button.
 */
public class GoalWidgetProvider extends AppWidgetProvider {

    static final String EXTRA_ADD_GOAL = "widget_add_goal";
    static final String EXTRA_GOAL_ID = "widget_goal_id";

    private static final int MAX_ROWS = 3;

    private static final int[] ROW = {R.id.w_row1, R.id.w_row2, R.id.w_row3};
    private static final int[] NAME = {R.id.w_name1, R.id.w_name2, R.id.w_name3};
    private static final int[] STARTED = {R.id.w_started1, R.id.w_started2, R.id.w_started3};
    private static final int[] PCT = {R.id.w_pct1, R.id.w_pct2, R.id.w_pct3};
    private static final int[] DAYS = {R.id.w_days1, R.id.w_days2, R.id.w_days3};
    // Dividers sit below row 1 and row 2.
    private static final int[] DIV = {R.id.w_div1, R.id.w_div2};

    private static final class Item {
        String id, name, created;
        int percent;      // ((total - remaining) / total) x 100, 0..100
        Long days;        // days remaining (null = no deadline, negative = passed)
        long totalDays;   // stored duration (start -> deadline)
        boolean completed;
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        List<Item> items = loadItems(context);
        scheduleMidnight(context);

        PendingIntent openApp = activity(context, 0, null, false);
        PendingIntent addGoal = activity(context, 1, null, true);

        for (int id : ids) {
            RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.goal_widget);

            for (int i = 0; i < MAX_ROWS; i++) {
                if (i < items.size()) {
                    Item it = items.get(i);
                    v.setViewVisibility(ROW[i], View.VISIBLE);
                    v.setTextViewText(NAME[i], it.name);
                    v.setTextViewText(STARTED[i], startedText(it.created));
                    String sub = it.completed ? "Completed \u2713"
                            : it.days != null && it.days < 0 ? "100% \u00b7 Expired"
                            : it.days == null ? "No deadline" : it.percent + "% complete";
                    v.setTextViewText(PCT[i], sub);
                    String remaining = it.days == null ? "–" : String.valueOf(Math.max(0, it.days));
                    String total = it.days == null ? "–" : String.valueOf(it.totalDays);
                    v.setTextViewText(DAYS[i], remaining + " / " + total);
                    v.setOnClickPendingIntent(ROW[i], activity(context, 10 + i, it.id, false));
                } else if (i == 0) {
                    // No goals at all: show a friendly placeholder row.
                    v.setViewVisibility(ROW[0], View.VISIBLE);
                    v.setTextViewText(NAME[0], "No goals yet – tap +");
                    v.setTextViewText(STARTED[0], "");
                    v.setTextViewText(PCT[0], "");
                    v.setTextViewText(DAYS[0], "–");
                    v.setOnClickPendingIntent(ROW[0], addGoal);
                } else {
                    v.setViewVisibility(ROW[i], View.GONE);
                }
            }
            // A divider is only shown when the row below it is visible.
            for (int d = 0; d < DIV.length; d++) {
                v.setViewVisibility(DIV[d], items.size() > d + 1 ? View.VISIBLE : View.GONE);
            }

            v.setOnClickPendingIntent(R.id.w_root, openApp);
            v.setOnClickPendingIntent(R.id.w_viewall, openApp);
            v.setOnClickPendingIntent(R.id.w_add, addGoal);
            manager.updateAppWidget(id, v);
        }
    }

    /** Builds a PendingIntent that opens the app, optionally selecting a goal or adding a new one. */
    private static PendingIntent activity(Context c, int requestCode, String goalId, boolean add) {
        Intent i = new Intent(c, MainActivity.class);
        i.setAction(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (goalId != null) i.putExtra(EXTRA_GOAL_ID, goalId);
        if (add) i.putExtra(EXTRA_ADD_GOAL, true);
        return PendingIntent.getActivity(c, requestCode, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Reads the live Store (single source of truth) and orders goals by soonest deadline. */
    private static List<Item> loadItems(Context c) {
        List<Item> out = new ArrayList<>();
        for (Store.Goal g : Store.get(c).goals) {
            Item it = new Item();
            it.id = g.id;
            it.name = g.title.isEmpty() ? "Untitled" : g.title;
            it.created = g.created;
            it.days = g.remaining();
            it.totalDays = g.total;
            it.percent = g.pctElapsed();
            it.completed = g.completed();
            out.add(it);
        }
        // Active first (soonest deadline on top), then completed/expired, then goals without a deadline.
        Collections.sort(out, (x, y) -> Long.compare(rank(x), rank(y)));
        return out.size() > MAX_ROWS ? new ArrayList<>(out.subList(0, MAX_ROWS)) : out;
    }

    /** "Started: 1 Oct 2026" */
    private static String startedText(String created) {
        LocalDate d = Util.parse(created);
        if (d == null) return "";
        return "Started: " + d.getDayOfMonth() + " " + Util.MONTHS_SHORT[d.getMonthValue() - 1] + " " + d.getYear();
    }

    private static long rank(Item it) {
        if (it.days == null) return Long.MAX_VALUE;
        if (it.completed) return 2_000_000L;
        if (it.days < 0) return 1_000_000L - it.days;
        return it.days;
    }

    private static final String ACTION_MIDNIGHT = "com.example.goaltracker.WIDGET_MIDNIGHT";

    /** Re-draws the widget when the date, time or time zone changes, so day counts stay current. */
    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String a = intent == null ? null : intent.getAction();
        if (Intent.ACTION_DATE_CHANGED.equals(a) || Intent.ACTION_TIME_CHANGED.equals(a)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(a) || ACTION_MIDNIGHT.equals(a)
                || Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            refresh(context);
        }
    }

    @Override public void onEnabled(Context c) { scheduleMidnight(c); }

    @Override public void onDisabled(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(midnightIntent(c));
    }

    private static PendingIntent midnightIntent(Context c) {
        Intent i = new Intent(c, GoalWidgetProvider.class).setAction(ACTION_MIDNIGHT);
        return PendingIntent.getBroadcast(c, 99, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Wakes the widget just after local midnight (inexact alarm, no special permission needed). */
    private static void scheduleMidnight(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() + 5000;
        am.setAndAllowWhileIdle(AlarmManager.RTC, at, midnightIntent(c));
    }

    /** Re-draws every placed widget (called whenever the app saves or the date changes). */
    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, GoalWidgetProvider.class));
        if (ids != null && ids.length > 0) {
            new GoalWidgetProvider().onUpdate(c, m, ids);
        }
    }
}
